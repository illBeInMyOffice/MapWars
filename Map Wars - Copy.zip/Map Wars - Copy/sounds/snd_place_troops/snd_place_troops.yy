{
  "name": "snd_place_troops",
  "compression": 0,
  "type": 0,
  "sampleRate": 44100,
  "bitDepth": 1,
  "bitRate": 128,
  "volume": 1.0,
  "preload": false,
  "audioGroupId": {
    "name": "audiogroup_default",
    "path": "audiogroups/audiogroup_default",
  },
  "soundFile": "snd_place_troops.mp3",
  "duration": 0.653,
  "parent": {
    "name": "Sounds",
    "path": "folders/Sounds.yy",
  },
  "resourceVersion": "1.0",
  "tags": [],
  "resourceType": "GMSound",
}