draw_set_font(-1);



draw_set_color(make_color_rgb(18, 28, 22));
draw_rectangle(0, 0, global.gui_w, global.gui_h, false);
draw_set_alpha(0.2);
draw_set_color(make_color_rgb(60, 80, 60));
draw_rectangle(0, 0, global.gui_w, global.gui_h, false);
draw_set_alpha(1);
draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);

draw_text(20, 20, "Civil War Strategy Prototype");

var phase_name = "";
switch (global.phase) {
    case global.PHASE_REINFORCE: phase_name = "Reinforce"; break;
    case global.PHASE_ATTACK: phase_name = "Attack"; break;
    case global.PHASE_MOVE: phase_name = "Move"; break;
}
var diff_name = "Normal";
switch (global.ai_difficulty) {
    case global.AI_EASY: diff_name = "Easy"; break;
    case global.AI_NORMAL: diff_name = "Normal"; break;
    case global.AI_NIGHTMARE: diff_name = "Nightmare"; break;
}

draw_text(20, 270, "CPU Difficulty: " + diff_name);

scr_draw_war_room_background(); // draws the background base

//var turn_name = (global.current_turn == global.OWNER_PLAYER) ? "Union" : "Confederacy";
//var buf = 20;
//draw_text(40, 50 + buf,  "Turn: " + turn_name);
//draw_text(40, 75 + buf,  "Phase: " + phase_name);
//draw_text(40, 100 + buf, "Reinforcements left: " + string(global.reinforcements_left));
//draw_text(40, 125 + buf, "SPACE = next phase / end turn");
//draw_text(40, 150 + buf, "R = restart");
//draw_text(40, 180 + buf, global.message);

// ---------------------------------
// Console UI panels
// ---------------------------------
scr_draw_status_panel(20, 70, 180, 110);
scr_draw_control_panel(20, 195, 180, 115);
scr_draw_controls_panel(20, global.gui_h - 170, 180, 120);
scr_draw_small_state_panel(global.gui_w - 160, 20, 140, 210);

// bottom-center message bar
scr_draw_message_bar(global.monitor_x + 80, global.monitor_y + global.monitor_h + 12, global.monitor_w - 160, 30);

var player_states = 0;
var ai_states = 0;
var i;

for (i = 0; i < array_length(global.states); i++) {
    if (global.states[i].owner == global.OWNER_PLAYER) {
        player_states += 1;
    } else {
        ai_states += 1;
    }
}



// Highlight neighbors
if (global.selected_state != -1) {
    var sel = global.states[global.selected_state];

    for (i = 0; i < array_length(sel.neighbors); i++) {
        var ni = sel.neighbors[i];
        scr_draw_state(ni, true, false);
    }
}

if (global.move_from_state != -1) {
    var ms = global.states[global.move_from_state];

    for (i = 0; i < array_length(ms.neighbors); i++) {
        var ni2 = ms.neighbors[i];
        if (global.states[ni2].owner == global.OWNER_PLAYER) {
            scr_draw_state(ni2, false, true);
        }
    }
}



// Main map
for (i = 0; i < array_length(global.states); i++) {
    scr_draw_state(i, i == global.selected_state, i == global.move_from_state);
}

if (global.map_intro_active) {
    var rx = scr_get_map_intro_reveal_x();

    draw_set_alpha(.1);
    draw_set_color(c_white);
    draw_rectangle(rx - 6, 0, rx + 6, display_get_gui_height(), false);

    draw_set_alpha(1);
    draw_set_color(c_white);
}

scr_draw_monitor_overlay();

// AI action highlight overlay
if (global.ai_highlight_timer > 0) {
    var t = global.ai_highlight_timer / global.AI_HIGHLIGHT_DURATION;
    var pulse_alpha = 0.35 + 0.45 * t;

    if (global.ai_highlight_a != -1) {
        scr_draw_state_highlight(global.ai_highlight_a, c_yellow, pulse_alpha, 4);
    }

    if (global.ai_highlight_b != -1) {
        scr_draw_state_highlight(global.ai_highlight_b, c_red, pulse_alpha, 4);
    }
}

scr_draw_floaters();

if (global.game_over) {
    draw_set_color(c_black);
    draw_rectangle(430, 300, 930, 430, false);
    draw_set_color(c_white);
    draw_text(520, 345, global.message);
}

// Small Northeast state troop list
/*var list_x = display_get_gui_width() - 160;
var list_y = 20;
var line_h = 18;

draw_set_halign(fa_left);
draw_set_valign(fa_top);
draw_set_color(c_white);
draw_set_font(-1)
draw_text(list_x, list_y, "Northeast Troops");

var row = 0;
var i;
var j;

for (i = 0; i < array_length(global.small_state_list); i++) {
    var abbr = global.small_state_list[i];

    for (j = 0; j < array_length(global.states); j++) {
        if (global.states[j].abbr == abbr) {
            draw_text(
                list_x,
                list_y + 24 + row * line_h,
                abbr + ": " + string(global.states[j].troops)
            );
            row += 1;
            break;
        }
    }
}