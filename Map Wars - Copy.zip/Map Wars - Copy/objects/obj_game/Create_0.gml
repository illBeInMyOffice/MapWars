randomize();

scr_init_states();
scr_ai_apply_difficulty(global.ai_difficulty);

global.gui_h = display_get_gui_height();
global.gui_w = display_get_gui_width();
global.selected_state = -1;
global.move_from_state = -1;
global.reinforcements_left = 0;
global.phase = global.PHASE_REINFORCE;
global.current_turn = global.OWNER_PLAYER;
global.message = "";
global.game_over = false;
global.winner = -1;
global.has_moved_this_turn = false;

global.AI_ACTION_DELAY = 60;
global.ai_action_queue = [];
global.ai_action_timer = 0;
global.ai_turn_in_progress = false;

global.ai_highlight_a = -1;
global.ai_highlight_b = -1;
global.ai_highlight_timer = 0;
global.AI_HIGHLIGHT_DURATION = global.AI_ACTION_DELAY;

global.floaters = [];
global.FLOATER_LIFE = 45;

global.map_intro_active = true;
global.map_intro_timer = 0;
global.map_intro_duration = 180;


audio_stop_all();
if !audio_is_playing(snd_music) {
	audio_play_sound(snd_music, 1, true)
}


scr_begin_turn(global.OWNER_PLAYER);