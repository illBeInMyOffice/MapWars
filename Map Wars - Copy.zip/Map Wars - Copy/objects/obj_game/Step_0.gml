if (keyboard_check_pressed(ord("R"))) {
    room_restart();
}

if (keyboard_check_pressed(vk_escape)) {
	room_goto(rm_title)
}

if (global.map_intro_active) {
    global.map_intro_timer += 1;

    if (global.map_intro_timer >= global.map_intro_duration) {
        global.map_intro_timer = global.map_intro_duration;
        global.map_intro_active = false;
    }

    exit;
}

if (global.game_over) exit;

if (global.ai_highlight_timer > 0) {
    global.ai_highlight_timer -= 1;

    if (global.ai_highlight_timer <= 0) {
        global.ai_highlight_a = -1;
        global.ai_highlight_b = -1;
        global.ai_highlight_timer = 0;
    }
}

if (global.map_intro_active) {
    global.map_intro_timer += 1;

    if (global.map_intro_timer >= global.map_intro_duration) {
        global.map_intro_timer = global.map_intro_duration;
        global.map_intro_active = false;
    }
}

scr_update_floaters();

if (global.current_turn == global.OWNER_AI) {
    if (!global.ai_turn_in_progress) {
        scr_ai_turn();
    }

    scr_process_ai_action();
    exit;
}

var mx = device_mouse_x_to_gui(0);
var my = device_mouse_y_to_gui(0);

if (mouse_check_button_pressed(mb_left)) {
    var clicked = scr_get_state_at_point(mx, my);

    switch (global.phase) {

        case global.PHASE_REINFORCE:
        {
            if (clicked != -1) {
                if (global.states[clicked].owner == global.OWNER_PLAYER && global.reinforcements_left > 0) {
                    global.states[clicked].troops += 1;
					global.reinforcements_left -= 1;

					audio_play_sound(snd_place_troops, 1, false);
					scr_spawn_floater(clicked, "+1", c_lime);
					global.message = "Placed 1 troop on " + global.states[clicked].abbr;

                    if (global.reinforcements_left <= 0) {
                        global.phase = global.PHASE_ATTACK;
                        global.message = "Attack phase: select your attacking state.";
                    }
                }
            }
            break;
        }

        case global.PHASE_ATTACK:
        {
            if (clicked != -1) {

                if (global.selected_state == -1) {

                    if (global.states[clicked].owner == global.OWNER_PLAYER && global.states[clicked].troops >= 2) {
                        global.selected_state = clicked;
                        global.message = "Selected " + global.states[clicked].abbr + ". Now click an enemy neighboring state to attack.";
                    }

                } else {

                    if (clicked == global.selected_state) {
                        global.selected_state = -1;
                        global.message = "Attack selection cleared.";

                    } else {

                        var src = global.states[global.selected_state];

                        var valid = false;
                        var i;
                        for (i = 0; i < array_length(src.neighbors); i++) {
                            if (src.neighbors[i] == clicked) {
                                valid = true;
                                break;
                            }
                        }

                        if (valid && global.states[clicked].owner == global.OWNER_AI) {

                            scr_attack_state(global.selected_state, clicked);

                            if (!scr_check_victory()) {
                                if (global.states[global.selected_state].troops < 2) {
                                    global.selected_state = -1;
                                }
                            }

                        } else if (global.states[clicked].owner == global.OWNER_PLAYER && global.states[clicked].troops >= 2) {

                            global.selected_state = clicked;
                            global.message = "Selected " + global.states[clicked].abbr + ".";

                        }
                    }
                }
            }
            break;
        }

        case global.PHASE_MOVE:
        {
            if (clicked != -1) {

                if (global.move_from_state == -1) {

                    if (global.states[clicked].owner == global.OWNER_PLAYER && global.states[clicked].troops >= 2) {
                        global.move_from_state = clicked;
                        global.message = "Move phase: select a neighboring friendly state.";
                    }

                } else {

                    if (clicked == global.move_from_state) {
                        global.move_from_state = -1;
                        global.message = "Move selection cleared.";

                    } else {

                        var src2 = global.states[global.move_from_state];

                        var can_move = false;
                        var j;
                        for (j = 0; j < array_length(src2.neighbors); j++) {
                            if (src2.neighbors[j] == clicked) {
                                can_move = true;
                                break;
                            }
                        }

                        if (can_move && global.states[clicked].owner == global.OWNER_PLAYER) {
                            global.states[global.move_from_state].troops -= 1;
                            global.states[clicked].troops += 1;

                            global.move_from_state = -1;
                            global.has_moved_this_turn = true;
                            global.message = "Moved 1 troop.";
                        }
                    }
                }
            }
            break;
        }
    }
}

if (keyboard_check_pressed(vk_space)) {

    if (global.current_turn == global.OWNER_PLAYER) {

        if (global.phase == global.PHASE_ATTACK) {

            global.phase = global.PHASE_MOVE;
            global.selected_state = -1;
            global.message = "Move phase: select a state with 2+ troops.";

        } else if (global.phase == global.PHASE_MOVE) {

            global.move_from_state = -1;
            global.selected_state = -1;

            scr_begin_turn(global.OWNER_AI);
        }
    }
}