title_selected = -1;
global.AI_EASY = 0;
global.AI_NORMAL = 1;
global.AI_NIGHTMARE = 2;

btn_w = 260;
btn_h = 56;
btn_gap = 20;

title_y = 110;
subtitle_y = 165;

start_x = 0;
start_y = 260;

btn_easy = {
    _x: 0,
    _y: 0,
    w: btn_w,
    h: btn_h,
    label: "Easy",
    difficulty: global.AI_EASY
};

btn_normal = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Normal",
    difficulty: global.AI_NORMAL
};

btn_nightmare = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Nightmare",
    difficulty: global.AI_NIGHTMARE
};

btn_quit = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Quit"
};

// Make sure state polygon data exists for title-screen flair
scr_init_states();

title_selected = -1;

btn_w = 260;
btn_h = 56;
btn_gap = 20;

title_y = 110;
subtitle_y = 165;

start_x = 0;
start_y = 260;

btn_easy = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Easy",
    difficulty: global.AI_EASY
};

btn_normal = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Normal",
    difficulty: global.AI_NORMAL
};

btn_nightmare = {
    x: 0,
    y: 0,
    w: btn_w,
    h: btn_h,
    label: "Nightmare",
    difficulty: global.AI_NIGHTMARE
};

// ---------------------------------
// Floating title-screen state flair
// ---------------------------------
audio_stop_all();
if !audio_is_playing(snd_title_music) {
	audio_play_sound(snd_title_music, 1, true)
}


title_floaters = [];
title_floater_count = 35;

var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

var i;
for (i = 0; i < title_floater_count; i++) {
    var state_index = irandom(array_length(global.states) - 1);

    var dir = random(360);
    var spd = random_range(0.15, 0.55);

    var floater = {
        state_index: state_index,
        x: random(gui_w),
        y: random(gui_h),
        vx: lengthdir_x(spd, dir),
        vy: lengthdir_y(spd, dir),
        rot: random(360),
        rot_spd: random_range(-0.25, 0.25),
        scale: random_range(1.00, 2.00),
        alpha: random_range(0.10, 0.22),
        col: choose(
            make_color_rgb(90, 110, 150),
            make_color_rgb(120, 90, 90),
            make_color_rgb(100, 100, 120)
        )
    };

    array_push(title_floaters, floater);
}