var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

var center_x = gui_w * 0.5;

btn_easy.x = center_x - btn_w * 0.5;
btn_easy.y = start_y;

btn_normal.x = center_x - btn_w * 0.5;
btn_normal.y = start_y + btn_h + btn_gap;

btn_nightmare.x = center_x - btn_w * 0.5;
btn_nightmare.y = start_y + (btn_h + btn_gap) * 2;

btn_quit.x = center_x - btn_w * 0.5;
btn_quit.y = start_y + (btn_h + btn_gap) * 3;

function point_in_button(_mx, _my, _btn) {
    return (_mx >= _btn.x && _mx <= _btn.x + _btn.w &&
            _my >= _btn.y && _my <= _btn.y + _btn.h);
}

var mx = device_mouse_x_to_gui(0);
var my = device_mouse_y_to_gui(0);

title_selected = -1;

if (point_in_button(mx, my, btn_easy)) {
    title_selected = 0;
}
else if (point_in_button(mx, my, btn_normal)) {
    title_selected = 1;
}
else if (point_in_button(mx, my, btn_nightmare)) {
    title_selected = 2;
}
else if (point_in_button(mx, my, btn_quit)) {
    title_selected = 3;
}

if (mouse_check_button_pressed(mb_left)) {
    if (title_selected == 0) {
        global.ai_difficulty = global.AI_EASY;
        room_goto(Room1);
    }
    else if (title_selected == 1) {
        global.ai_difficulty = global.AI_NORMAL;
        room_goto(Room1);
    }
    else if (title_selected == 2) {
        global.ai_difficulty = global.AI_NIGHTMARE;
        room_goto(Room1);
    }
    else if (title_selected == 3) {
        game_end();
    }
}

// Update floating state flair
var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();

var i;
for (i = 0; i < array_length(title_floaters); i++) {
    var f = title_floaters[i];

    f.x += f.vx;
    f.y += f.vy;
    f.rot += f.rot_spd;

    var margin = 120;

    if (f.x < -margin) f.x = gui_w + margin;
    if (f.x > gui_w + margin) f.x = -margin;
    if (f.y < -margin) f.y = gui_h + margin;
    if (f.y > gui_h + margin) f.y = -margin;

    title_floaters[i] = f;
}