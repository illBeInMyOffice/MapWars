var gui_w = display_get_gui_width();
var gui_h = display_get_gui_height();
var center_x = gui_w * 0.5;

draw_set_halign(fa_center);
draw_set_valign(fa_top);

// Background
draw_set_color(make_color_rgb(12, 12, 18));
draw_rectangle(0, 0, gui_w, gui_h, false);

// Floating state background flair
var i;
for (i = 0; i < array_length(title_floaters); i++) {
    scr_draw_title_state_floater(title_floaters[i]);
}


var center_x = gui_w * 0.5;

scr_draw_title_logo(center_x - 260, 40, 1);


// Subtitle
//draw_set_color(make_color_rgb(200, 200, 200));
// draw_text(center_x, subtitle_y, "Choose CPU Difficulty");

// Easy button
draw_set_color(c_green);
draw_set_alpha(.5);
draw_button(
    btn_easy.x,
    btn_easy.y,
    btn_easy.x + btn_easy.w,
    btn_easy.y + btn_easy.h,
    !(title_selected == 0)
);

draw_set_alpha(1);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_black);
draw_text(btn_easy.x + btn_easy.w * 0.5, btn_easy.y + btn_easy.h * 0.5, btn_easy.label);

draw_set_halign(fa_center);
draw_set_valign(fa_top);
draw_set_color(make_color_rgb(190, 190, 190));
draw_text(btn_easy.x + btn_easy.w * 0.5, btn_easy.y + btn_easy.h + 0, "More random, less aggressive");

// Normal button
draw_set_color(c_olive);
draw_set_alpha(.5);
draw_button(
    btn_normal.x,
    btn_normal.y,
    btn_normal.x + btn_normal.w,
    btn_normal.y + btn_normal.h,
    !(title_selected == 1)
);

draw_set_alpha(1);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_black);
draw_text(btn_normal.x + btn_normal.w * 0.5, btn_normal.y + btn_normal.h * 0.5, btn_normal.label);

draw_set_halign(fa_center);
draw_set_valign(fa_top);
draw_set_color(make_color_rgb(190, 190, 190));
draw_text(btn_normal.x + btn_normal.w * 0.5, btn_normal.y + btn_normal.h + 0, "Balanced AI");

// Nightmare button
draw_set_color(c_red);
draw_set_alpha(.5);
draw_button(
    btn_nightmare.x,
    btn_nightmare.y,
    btn_nightmare.x + btn_nightmare.w,
    btn_nightmare.y + btn_nightmare.h,
    !(title_selected == 2)
);

draw_set_alpha(1);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_black);
draw_text(btn_nightmare.x + btn_nightmare.w * 0.5, btn_nightmare.y + btn_nightmare.h * 0.5, btn_nightmare.label);

draw_set_halign(fa_center);
draw_set_valign(fa_top);
draw_set_color(make_color_rgb(190, 190, 190));
draw_text(btn_nightmare.x + btn_nightmare.w * 0.5, btn_nightmare.y + btn_nightmare.h + 0, "Much smarter and more aggressive");

// Quit button
draw_set_color(c_white);
draw_set_alpha(.5);
draw_button(
    btn_quit.x,
    btn_quit.y,
    btn_quit.x + btn_quit.w,
    btn_quit.y + btn_quit.h,
    !(title_selected == 3)
);

draw_set_alpha(1);
draw_set_halign(fa_center);
draw_set_valign(fa_middle);
draw_set_color(c_black);
draw_text(btn_quit.x + btn_quit.w * 0.5, btn_quit.y + btn_quit.h * 0.5, btn_quit.label);

draw_set_halign(fa_center);
draw_set_valign(fa_top);
draw_set_color(make_color_rgb(190, 190, 190));
draw_text(btn_quit.x + btn_quit.w * 0.5, btn_quit.y + btn_quit.h + 0, "Exit the game");

// Footer
draw_set_halign(fa_center);
draw_set_valign(fa_top);
draw_set_color(make_color_rgb(160, 160, 160));
draw_text(center_x, gui_h - 48, "Click a difficulty to begin");