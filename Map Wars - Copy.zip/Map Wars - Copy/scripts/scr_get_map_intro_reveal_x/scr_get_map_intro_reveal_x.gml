function scr_get_map_intro_reveal_x() {
    var gui_w = display_get_gui_width();

    var t = global.map_intro_timer / global.map_intro_duration;
    t = clamp(t, 0, 1);

    // Smooth easing
    t = 1 - power(1 - t, 3);

    var start_x = -50;
    var end_x = gui_w + 50;

    return lerp(start_x, end_x, t);
}