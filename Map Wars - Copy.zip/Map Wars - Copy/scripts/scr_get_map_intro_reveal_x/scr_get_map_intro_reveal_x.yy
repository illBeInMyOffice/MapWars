{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_get_map_intro_reveal_x",
  "tags": [],
  "resourceType": "GMScript",
}