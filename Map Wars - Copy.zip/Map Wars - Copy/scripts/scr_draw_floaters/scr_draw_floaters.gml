function scr_draw_floaters() {
    var i;

	draw_set_font(fnt_floater);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    for (i = 0; i < array_length(global.floaters); i++) {
        var f = global.floaters[i];
        var a = f.life / f.max_life;

        draw_set_alpha(a);
        draw_set_color(c_black);
		draw_text(f.x + 1, f.y + 1, f.text);

		draw_set_color(f.col);
		draw_text(f.x, f.y, f.text);
    }

    draw_set_alpha(1);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}

draw_set_font(-1);