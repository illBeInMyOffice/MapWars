function scr_draw_console_panel(_x, _y, _w, _h, _title) {
    var x1 = _x;
    var y1 = _y;
    var x2 = _x + _w;
    var y2 = _y + _h;

    // panel shadow
    draw_set_alpha(0.18);
    draw_set_color(c_black);
    draw_rectangle(x1 + 3, y1 + 3, x2 + 3, y2 + 3, false);
    draw_set_alpha(1);

    // panel fill
    draw_set_color(make_color_rgb(20, 24, 24));
    draw_rectangle(x1, y1, x2, y2, false);

    // panel outline
    draw_set_color(make_color_rgb(210, 210, 210));
    draw_rectangle(x1, y1, x2, y2, true);

    // title strip
    draw_set_color(make_color_rgb(70, 66, 38));
    draw_rectangle(x1 + 8, y1 + 8, x2 - 8, y1 + 16, false);

    draw_set_color(make_color_rgb(255, 210, 80));
    draw_line_width(x1 + 12, y1 + 12, x2 - 12, y1 + 12, 2);
    draw_circle((x1 + x2) * 0.5, y1 + 12, 3, false);

    // title text
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(make_color_rgb(235, 235, 235));
    draw_text(x1 + 10, y1 - 2, _title);
}