function scr_draw_status_panel(_x, _y, _w, _h) {
    scr_draw_console_panel(_x, _y, _w, _h, "");

    var side_name = "UNION";
    var side_col = make_color_rgb(90, 140, 255);

    if (global.current_turn == global.OWNER_AI) {
        side_name = "CONFED";
        side_col = make_color_rgb(220, 95, 95);
    }

    var phase_name = "REINFORCE";
    switch (global.phase) {
        case global.PHASE_REINFORCE: phase_name = "REINFORCE"; break;
        case global.PHASE_ATTACK:    phase_name = "ATTACK";    break;
        case global.PHASE_MOVE:      phase_name = "MOVE";      break;
    }

    var label_col = make_color_rgb(160, 180, 170);
    var value_col = make_color_rgb(235, 235, 235);

    var lx = _x + 14;
    var rx = _x + _w - 14;
    var y0 = _y + 30;
    var row_h = 24;

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    draw_set_color(label_col);
    draw_text(lx, y0 + row_h * 0, "SIDE");
    draw_text(lx, y0 + row_h * 1, "PHASE");
    draw_text(lx, y0 + row_h * 2, "RESERVE");

    draw_set_halign(fa_right);

    draw_set_color(side_col);
    draw_text(rx, y0 + row_h * 0, side_name);

    draw_set_color(value_col);
    draw_text(rx, y0 + row_h * 1, phase_name);
    draw_text(rx, y0 + row_h * 2, string(global.reinforcements_left));

    // colored side indicator
    draw_set_color(side_col);
    draw_circle(_x + _w-10 , _y + 38, 5, false);

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}