function scr_draw_small_state_panel(_x, _y, _w, _h) {
    scr_draw_console_panel(_x, _y, _w, _h, "");

    var label_col = make_color_rgb(160, 180, 170);
    var blue_col = make_color_rgb(90, 140, 255);
    var red_col = make_color_rgb(220, 95, 95);

    var row_h = 18;
    var start_y = _y + 30;

    var i, j;

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    for (i = 0; i < array_length(global.small_state_list); i++) {
        var abbr = global.small_state_list[i];

        for (j = 0; j < array_length(global.states); j++) {
            var st = global.states[j];

            if (st.abbr == abbr) {
                var row_y = start_y + i * row_h;

                // row backing
                if ((i mod 2) == 0) {
                    draw_set_alpha(0.12);
                    draw_set_color(make_color_rgb(90, 90, 90));
                    draw_rectangle(_x + 8, row_y, _x + _w - 8, row_y + row_h - 2, false);
                    draw_set_alpha(1);
                }

                draw_set_color(label_col);
                draw_text(_x + 12, row_y, abbr);

                if (st.owner == global.OWNER_PLAYER) {
                    draw_set_color(blue_col);
                } else {
                    draw_set_color(red_col);
                }

                draw_set_halign(fa_right);
                draw_text(_x + _w - 12, row_y, string(st.troops));
                draw_set_halign(fa_left);

                break;
            }
        }
    }

    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}