{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_draw_small_state_panel",
  "tags": [],
  "resourceType": "GMScript",
}