function scr_draw_controls_panel(_x, _y, _w, _h) {
    scr_draw_console_panel(_x, _y, _w, _h, "");

    var label_col = make_color_rgb(220, 220, 220);
    var sub_col = make_color_rgb(160, 180, 170);

    var key_w = 58;
    var key_h = 20;

    var row1_y = _y + 30;
    var row2_y = _y + 58;
    var row3_y = _y + 86;

    // SPACE
    draw_set_color(c_white);
    draw_button(_x + 12, row1_y, _x + 12 + key_w, row1_y + key_h, true);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_text(_x + 12 + key_w * 0.5, row1_y + key_h * 0.5, "SPACE");

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(sub_col);
    draw_text(_x + 12 + key_w + 10, row1_y + 2, "NEXT PHASE");

    // R
    draw_set_color(c_white);
    draw_button(_x + 12, row2_y, _x + 12 + key_w, row2_y + key_h, true);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_text(_x + 12 + key_w * 0.5, row2_y + key_h * 0.5, "R");

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(sub_col);
    draw_text(_x + 12 + key_w + 10, row2_y + 2, "RESTART");

    // ESC
    draw_set_color(c_white);
    draw_button(_x + 12, row3_y, _x + 12 + key_w, row3_y + key_h, true);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(c_black);
    draw_text(_x + 12 + key_w * 0.5, row3_y + key_h * 0.5, "ESC");

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(sub_col);
    draw_text(_x + 12 + key_w + 10, row3_y + 2, "TITLE");

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(label_col);
}