function scr_ai_apply_difficulty(_difficulty) {
    global.ai_difficulty = _difficulty;

    switch (_difficulty) {
        case global.AI_EASY:
        {
            global.ai_profile = {
                reinforce_front_bias: 0.45,
                reinforce_weak_front_bias: 0.35,
                reinforce_randomness: 0.90,

                attack_min_advantage: 2,
                attack_equal_chance: 0.08,
                attack_risky_chance: 0.03,
                attack_max_actions: 5,

                move_frontline_bias: 0.45,
                move_support_bias: 0.30,
                move_randomness: 0.85
            };
            break;
        }

        case global.AI_NORMAL:
        {
            global.ai_profile = {
                reinforce_front_bias: 0.90,
                reinforce_weak_front_bias: 0.80,
                reinforce_randomness: 0.35,

                attack_min_advantage: 1,
                attack_equal_chance: 0.25,
                attack_risky_chance: 0.08,
                attack_max_actions: 7,

                move_frontline_bias: 0.90,
                move_support_bias: 0.70,
                move_randomness: 0.25
            };
            break;
        }

        case global.AI_NIGHTMARE:
        {
            global.ai_profile = {
                reinforce_front_bias: 1.50,
                reinforce_weak_front_bias: 1.30,
                reinforce_randomness: 0.08,

                attack_min_advantage: 0,
                attack_equal_chance: 0.65,
                attack_risky_chance: 0.18,
                attack_max_actions: 8,

                move_frontline_bias: 1.40,
                move_support_bias: 1.10,
                move_randomness: 0.05
            };
            break;
        }
    }
}