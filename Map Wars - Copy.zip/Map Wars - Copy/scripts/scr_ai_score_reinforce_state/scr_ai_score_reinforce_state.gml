function scr_ai_score_reinforce_state(_state_index) {
    var p = global.ai_profile;
    var s = global.states[_state_index];

    if (s.owner != global.OWNER_AI) return -999999;

    var _score = 0;

    var is_frontline = scr_ai_state_is_frontline(_state_index, global.OWNER_PLAYER);
    var enemy_neighbors = scr_ai_count_enemy_neighbors(_state_index, global.OWNER_PLAYER);
    var strongest_enemy = scr_ai_get_strongest_adjacent_enemy(_state_index, global.OWNER_PLAYER);

    if (is_frontline) {
        _score += 10 * p.reinforce_front_bias;
        _score += enemy_neighbors * 4 * p.reinforce_front_bias;

        if (strongest_enemy != -1) {
            var enemy_troops = global.states[strongest_enemy].troops;
            var deficit = max(0, enemy_troops - s.troops);
            _score += deficit * 5 * p.reinforce_weak_front_bias;
        }
    } else {
        _score += 1;
    }

    _score += random(p.reinforce_randomness * 10);

    return _score;
}