{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_ai_count_enemy_neighbors",
  "tags": [],
  "resourceType": "GMScript",
}