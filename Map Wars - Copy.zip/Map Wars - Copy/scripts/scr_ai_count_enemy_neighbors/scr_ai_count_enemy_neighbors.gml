function scr_ai_count_enemy_neighbors(_state_index, _enemy_owner) {
    var s = global.states[_state_index];
    var count = 0;
    var i;

    for (i = 0; i < array_length(s.neighbors); i++) {
        var ni = s.neighbors[i];
        if (global.states[ni].owner == _enemy_owner) {
            count += 1;
        }
    }

    return count;
}