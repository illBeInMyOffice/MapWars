function scr_is_small_state_listed(_abbr) {
    var i;
    for (i = 0; i < array_length(global.small_state_list); i++) {
        if (global.small_state_list[i] == _abbr) {
            return true;
        }
    }
    return false;
}