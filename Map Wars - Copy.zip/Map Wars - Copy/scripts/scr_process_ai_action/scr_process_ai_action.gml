function scr_process_ai_action() {
    if (!global.ai_turn_in_progress) return;

    if (global.ai_action_timer > 0) {
        global.ai_action_timer -= 1;
        return;
    }

    if (array_length(global.ai_action_queue) <= 0) {
        global.ai_turn_in_progress = false;
        global.ai_highlight_a = -1;
        global.ai_highlight_b = -1;
        global.ai_highlight_timer = 0;

        if (!scr_check_victory()) {
            scr_begin_turn(global.OWNER_PLAYER);
        }

        return;
    }

    var action = global.ai_action_queue[0];

    var new_queue = [];
    var i;
    for (i = 1; i < array_length(global.ai_action_queue); i++) {
        array_push(new_queue, global.ai_action_queue[i]);
    }
    global.ai_action_queue = new_queue;

    switch (action.type) {
        case "reinforce":
{
    if (global.states[action.state_index].owner == global.OWNER_AI) {
        global.states[action.state_index].troops += 1;
        audio_play_sound(snd_place_troops, 1, false);
        scr_spawn_floater(action.state_index, "+1", c_lime);
        global.message = "CPU placed 1 troop on " + global.states[action.state_index].abbr;

        scr_set_ai_highlight(action.state_index, -1);
    }
    break;
}

        case "attack":
        {
            if (action.from_index >= 0 && action.to_index >= 0) {
                if (global.states[action.from_index].owner == global.OWNER_AI &&
                    global.states[action.to_index].owner == global.OWNER_PLAYER &&
                    global.states[action.from_index].troops >= 2) {

                    scr_attack_state(action.from_index, action.to_index);
                    scr_set_ai_highlight(action.from_index, action.to_index);
                    scr_check_victory();
                }
            }
            break;
        }

        case "move":
{
    if (action.from_index >= 0 && action.to_index >= 0) {
        if (global.states[action.from_index].owner == global.OWNER_AI &&
            global.states[action.to_index].owner == global.OWNER_AI &&
            global.states[action.from_index].troops >= 2) {

	            global.states[action.from_index].troops -= 1;
	            global.states[action.to_index].troops += 1;

	            scr_spawn_floater(action.from_index, "-1", c_yellow);
	            scr_spawn_floater(action.to_index, "+1", c_lime);

	            global.message = "CPU moved 1 troop from " +
	            global.states[action.from_index].abbr + " to " +
	            global.states[action.to_index].abbr;

	            scr_set_ai_highlight(action.from_index, action.to_index);
	        }
	    }
	    break;
	}
   }

    global.ai_action_timer = global.AI_ACTION_DELAY;
}