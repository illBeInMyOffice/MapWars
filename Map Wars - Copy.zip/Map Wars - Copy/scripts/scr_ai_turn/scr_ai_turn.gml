function scr_ai_turn() {
    global.ai_action_queue = [];
    global.ai_action_timer = global.AI_ACTION_DELAY;
    global.ai_turn_in_progress = true;

    var p = global.ai_profile;
    var i, n, k;

    // Temporary planning arrays
    var plan_owner = [];
    var plan_troops = [];

    for (i = 0; i < array_length(global.states); i++) {
        plan_owner[i] = global.states[i].owner;
        plan_troops[i] = global.states[i].troops;
    }

    // -----------------------------
    // Reinforcement planning
    // -----------------------------
    var r = scr_calculate_reinforcements(global.OWNER_AI);

    repeat (r) {
        var best_reinf_idx = -1;
        var best_reinf_score = -999999;

        for (i = 0; i < array_length(global.states); i++) {
            if (plan_owner[i] != global.OWNER_AI) continue;

            var _score = 0;
            var is_frontline = false;
            var enemy_neighbors = 0;
            var strongest_enemy_troops = -1;

            var s = global.states[i];

            for (n = 0; n < array_length(s.neighbors); n++) {
                var ni = s.neighbors[n];

                if (plan_owner[ni] == global.OWNER_PLAYER) {
                    is_frontline = true;
                    enemy_neighbors += 1;

                    if (plan_troops[ni] > strongest_enemy_troops) {
                        strongest_enemy_troops = plan_troops[ni];
                    }
                }
            }

            if (is_frontline) {
                _score += 10 * p.reinforce_front_bias;
                _score += enemy_neighbors * 4 * p.reinforce_front_bias;

                if (strongest_enemy_troops != -1) {
                    var deficit = max(0, strongest_enemy_troops - plan_troops[i]);
                    _score += deficit * 5 * p.reinforce_weak_front_bias;
                }
            } else {
                _score += 1;
            }

            _score += random(p.reinforce_randomness * 10);

            if (_score > best_reinf_score) {
                best_reinf_score = _score;
                best_reinf_idx = i;
            }
        }

        if (best_reinf_idx != -1) {
            array_push(global.ai_action_queue, {
                type: "reinforce",
                state_index: best_reinf_idx
            });

            plan_troops[best_reinf_idx] += 1;
        }
    }

    // -----------------------------
    // Attack planning
    // -----------------------------
    repeat (p.attack_max_actions) {
        var best_attack_from = -1;
        var best_attack_to = -1;
        var best_attack_score = -999999;

        for (i = 0; i < array_length(global.states); i++) {
            if (plan_owner[i] != global.OWNER_AI) continue;
            if (plan_troops[i] < 2) continue;

            var from_state = global.states[i];

            for (n = 0; n < array_length(from_state.neighbors); n++) {
                var target_i = from_state.neighbors[n];

                if (plan_owner[target_i] != global.OWNER_PLAYER) continue;

                var available_attack_power = plan_troops[i] - 1;
                var diff = available_attack_power - plan_troops[target_i];
                var valid = true;
                var score2 = 0;

                if (diff < -1) {
                    if (random(1) > p.attack_risky_chance) valid = false;
                } else if (diff == -1 || diff == 0) {
                    if (random(1) > p.attack_equal_chance) valid = false;
                } else {
                    if (diff < p.attack_min_advantage) valid = false;
                }

                if (!valid) continue;

                score2 += diff * 10;
                score2 += max(0, 6 - plan_troops[target_i]) * 2;

                var enemy_neighbors_of_target = 0;
                var target_state = global.states[target_i];

                for (k = 0; k < array_length(target_state.neighbors); k++) {
                    var nn = target_state.neighbors[k];
                    if (plan_owner[nn] == global.OWNER_PLAYER) {
                        enemy_neighbors_of_target += 1;
                    }
                }

                score2 += enemy_neighbors_of_target * 2;
                score2 += random(2);

                if (score2 > best_attack_score) {
                    best_attack_score = score2;
                    best_attack_from = i;
                    best_attack_to = target_i;
                }
            }
        }

        if (best_attack_from == -1 || best_attack_to == -1) {
            break;
        }

        array_push(global.ai_action_queue, {
            type: "attack",
            from_index: best_attack_from,
            to_index: best_attack_to
        });

        // crude planning simulation
        var sim_attack_power = plan_troops[best_attack_from] - 1;
        var sim_defend_power = plan_troops[best_attack_to];

        if (sim_attack_power >= sim_defend_power) {
            plan_troops[best_attack_to] -= 1;

            if (plan_troops[best_attack_to] <= 0) {
                plan_owner[best_attack_to] = global.OWNER_AI;
                plan_troops[best_attack_to] = 1;
                plan_troops[best_attack_from] -= 1;
            }
        } else {
            plan_troops[best_attack_from] -= 1;
        }

        if (plan_troops[best_attack_from] < 1) {
            plan_troops[best_attack_from] = 1;
        }
    }

    // -----------------------------
    // Move planning
    // -----------------------------
    var best_move_from = -1;
    var best_move_to = -1;
    var best_move_score = -999999;

    for (i = 0; i < array_length(global.states); i++) {
        if (plan_owner[i] != global.OWNER_AI) continue;
        if (plan_troops[i] < 2) continue;

        var move_from_state = global.states[i];

        var from_is_frontline = false;
        for (n = 0; n < array_length(move_from_state.neighbors); n++) {
            if (plan_owner[move_from_state.neighbors[n]] == global.OWNER_PLAYER) {
                from_is_frontline = true;
                break;
            }
        }

        for (n = 0; n < array_length(move_from_state.neighbors); n++) {
            var move_to_i = move_from_state.neighbors[n];
            if (plan_owner[move_to_i] != global.OWNER_AI) continue;

            var move_score = 0;
            var to_state = global.states[move_to_i];
            var to_is_frontline = false;
            var to_enemy_neighbors = 0;
            var strongest_enemy_to = -1;

            for (k = 0; k < array_length(to_state.neighbors); k++) {
                var adj = to_state.neighbors[k];
                if (plan_owner[adj] == global.OWNER_PLAYER) {
                    to_is_frontline = true;
                    to_enemy_neighbors += 1;

                    if (plan_troops[adj] > strongest_enemy_to) {
                        strongest_enemy_to = plan_troops[adj];
                    }
                }
            }

            if (!from_is_frontline && to_is_frontline) {
                move_score += 14 * p.move_frontline_bias;
            }

            move_score += to_enemy_neighbors * 4 * p.move_support_bias;

            if (strongest_enemy_to != -1) {
                var deficit2 = max(0, strongest_enemy_to - plan_troops[move_to_i]);
                move_score += deficit2 * 4 * p.move_support_bias;
            }

            if (from_is_frontline && plan_troops[i] <= 3) {
                move_score -= 12;
            }

            move_score += random(p.move_randomness * 10);

            if (move_score > best_move_score) {
                best_move_score = move_score;
                best_move_from = i;
                best_move_to = move_to_i;
            }
        }
    }

    if (best_move_from != -1 && best_move_to != -1) {
        array_push(global.ai_action_queue, {
            type: "move",
            from_index: best_move_from,
            to_index: best_move_to
        });
    }
}