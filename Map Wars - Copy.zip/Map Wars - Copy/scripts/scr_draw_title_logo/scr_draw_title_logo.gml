function scr_draw_title_logo(_x, _y, _scale) {
    var tx = _x;
    var ty = _y;
    var sc = _scale;

    var t = current_time * 0.0025;
    var pulse = 0.5 + 0.5 * sin(t);
    var scan = frac(current_time * 0.00035);

    var col_fill = make_color_rgb(38, 48, 64);
    var col_outline = make_color_rgb(230, 230, 235);
    var col_accent = make_color_rgb(255, 210, 80);
    var col_shadow = c_black;

    var frame_w = 520 * sc;
    var frame_h = 180 * sc;

    var letter_w = 42 * sc;
    var letter_h = 52 * sc;
    var stroke = 8 * sc;
    var gap = 10 * sc;

    var top_y = ty + 34 * sc;
    var bot_y = ty + 98 * sc;
    var left_x = tx + 36 * sc;

    var sh = 3 * sc;

    // Frame shadow
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(tx + 5 * sc, ty + 5 * sc, tx + frame_w + 5 * sc, ty + frame_h + 5 * sc, false);
    draw_set_alpha(1);

    // Frame fill
    draw_set_color(make_color_rgb(18, 22, 30));
    draw_rectangle(tx, ty, tx + frame_w, ty + frame_h, false);

    // Frame outlines
    draw_set_color(col_outline);
    draw_rectangle(tx, ty, tx + frame_w, ty + frame_h, true);
    draw_rectangle(tx + 8 * sc, ty + 8 * sc, tx + frame_w - 8 * sc, ty + frame_h - 8 * sc, true);

    // Corner accents
    draw_set_color(col_accent);
    draw_line_width(tx + 10 * sc, ty + 10 * sc, tx + 36 * sc, ty + 10 * sc, 2);
    draw_line_width(tx + 10 * sc, ty + 10 * sc, tx + 10 * sc, ty + 36 * sc, 2);

    draw_line_width(tx + frame_w - 10 * sc, ty + 10 * sc, tx + frame_w - 36 * sc, ty + 10 * sc, 2);
    draw_line_width(tx + frame_w - 10 * sc, ty + 10 * sc, tx + frame_w - 10 * sc, ty + 36 * sc, 2);

    draw_line_width(tx + 10 * sc, ty + frame_h - 10 * sc, tx + 36 * sc, ty + frame_h - 10 * sc, 2);
    draw_line_width(tx + 10 * sc, ty + frame_h - 10 * sc, tx + 10 * sc, ty + frame_h - 36 * sc, 2);

    draw_line_width(tx + frame_w - 10 * sc, ty + frame_h - 10 * sc, tx + frame_w - 36 * sc, ty + frame_h - 10 * sc, 2);
    draw_line_width(tx + frame_w - 10 * sc, ty + frame_h - 10 * sc, tx + frame_w - 10 * sc, ty + frame_h - 36 * sc, 2);

    // Animated scan line
    var line_y = ty + 28 * sc + scan * (frame_h - 56 * sc);
    draw_set_alpha(0.12 + 0.10 * pulse);
    draw_set_color(col_accent);
    draw_rectangle(tx + 16 * sc, line_y, tx + frame_w - 16 * sc, line_y + 6 * sc, false);
    draw_set_alpha(1);

    // Divider
    draw_set_color(col_accent);
    draw_line_width(tx + 70 * sc, ty + 88 * sc, tx + frame_w - 70 * sc, ty + 88 * sc, 2);
    draw_circle(tx + frame_w * 0.5, ty + 88 * sc, 4 * sc, false);

    // Decorative diagonals
    draw_set_alpha(0.18);
    draw_line_width(tx + 120 * sc, ty + 36 * sc, tx + 190 * sc, ty + 78 * sc, 2);
    draw_line_width(tx + 310 * sc, ty + 98 * sc, tx + 385 * sc, ty + 140 * sc, 2);
    draw_set_alpha(1);

    // -------------------------
    // MAP
    // -------------------------

    var lx = left_x + 60;

    // M
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, top_y + sh, lx + stroke + sh, top_y + letter_h + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, top_y + sh, lx + letter_w + sh, top_y + letter_h + sh, false);
    draw_rectangle(lx + 12 * sc + sh, top_y + 10 * sc + sh, lx + 12 * sc + stroke + sh, top_y + 34 * sc + sh, false);
    draw_rectangle(lx + 22 * sc + sh, top_y + 10 * sc + sh, lx + 22 * sc + stroke + sh, top_y + 34 * sc + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, top_y, lx + stroke, top_y + letter_h, false);
    draw_rectangle(lx + letter_w - stroke, top_y, lx + letter_w, top_y + letter_h, false);
    draw_rectangle(lx + 12 * sc, top_y + 10 * sc, lx + 12 * sc + stroke, top_y + 34 * sc, false);
    draw_rectangle(lx + 22 * sc, top_y + 10 * sc, lx + 22 * sc + stroke, top_y + 34 * sc, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, top_y, lx + stroke, top_y + letter_h, true);
    draw_rectangle(lx + letter_w - stroke, top_y, lx + letter_w, top_y + letter_h, true);
    draw_rectangle(lx + 12 * sc, top_y + 10 * sc, lx + 12 * sc + stroke, top_y + 34 * sc, true);
    draw_rectangle(lx + 22 * sc, top_y + 10 * sc, lx + 22 * sc + stroke, top_y + 34 * sc, true);

    lx += letter_w + gap;

    // A
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, top_y + 8 * sc + sh, lx + stroke + sh, top_y + letter_h + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, top_y + 8 * sc + sh, lx + letter_w + sh, top_y + letter_h + sh, false);
    draw_rectangle(lx + 6 * sc + sh, top_y + sh, lx + letter_w - 6 * sc + sh, top_y + stroke + sh, false);
    draw_rectangle(lx + 6 * sc + sh, top_y + 22 * sc + sh, lx + letter_w - 6 * sc + sh, top_y + 22 * sc + stroke + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, top_y + 8 * sc, lx + stroke, top_y + letter_h, false);
    draw_rectangle(lx + letter_w - stroke, top_y + 8 * sc, lx + letter_w, top_y + letter_h, false);
    draw_rectangle(lx + 6 * sc, top_y, lx + letter_w - 6 * sc, top_y + stroke, false);
    draw_rectangle(lx + 6 * sc, top_y + 22 * sc, lx + letter_w - 6 * sc, top_y + 22 * sc + stroke, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, top_y + 8 * sc, lx + stroke, top_y + letter_h, true);
    draw_rectangle(lx + letter_w - stroke, top_y + 8 * sc, lx + letter_w, top_y + letter_h, true);
    draw_rectangle(lx + 6 * sc, top_y, lx + letter_w - 6 * sc, top_y + stroke, true);
    draw_rectangle(lx + 6 * sc, top_y + 22 * sc, lx + letter_w - 6 * sc, top_y + 22 * sc + stroke, true);

    lx += letter_w + gap;

    // P
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, top_y + sh, lx + stroke + sh, top_y + letter_h + sh, false);
    draw_rectangle(lx + stroke + sh, top_y + sh, lx + letter_w + sh, top_y + stroke + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, top_y + sh, lx + letter_w + sh, top_y + 22 * sc + sh, false);
    draw_rectangle(lx + stroke + sh, top_y + 22 * sc + sh, lx + letter_w + sh, top_y + 22 * sc + stroke + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, top_y, lx + stroke, top_y + letter_h, false);
    draw_rectangle(lx + stroke, top_y, lx + letter_w, top_y + stroke, false);
    draw_rectangle(lx + letter_w - stroke, top_y, lx + letter_w, top_y + 22 * sc, false);
    draw_rectangle(lx + stroke, top_y + 22 * sc, lx + letter_w, top_y + 22 * sc + stroke, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, top_y, lx + stroke, top_y + letter_h, true);
    draw_rectangle(lx + stroke, top_y, lx + letter_w, top_y + stroke, true);
    draw_rectangle(lx + letter_w - stroke, top_y, lx + letter_w, top_y + 22 * sc, true);
    draw_rectangle(lx + stroke, top_y + 22 * sc, lx + letter_w, top_y + 22 * sc + stroke, true);

    // inner cutout for P
    draw_set_color(make_color_rgb(18, 22, 30));
    draw_rectangle(lx + 14 * sc, top_y + 8 * sc, lx + 26 * sc, top_y + 18 * sc, false);

    // -------------------------
    // WARS
    // -------------------------

    lx = left_x + 190 * sc;

    // W
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, bot_y + sh, lx + stroke + sh, bot_y + letter_h - 6 * sc + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, bot_y + sh, lx + letter_w + sh, bot_y + letter_h - 6 * sc + sh, false);
    draw_rectangle(lx + 12 * sc + sh, bot_y + 20 * sc + sh, lx + 12 * sc + stroke + sh, bot_y + 44 * sc + sh, false);
    draw_rectangle(lx + 22 * sc + sh, bot_y + 20 * sc + sh, lx + 22 * sc + stroke + sh, bot_y + 44 * sc + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + letter_h - 6 * sc, false);
    draw_rectangle(lx + letter_w - stroke, bot_y, lx + letter_w, bot_y + letter_h - 6 * sc, false);
    draw_rectangle(lx + 12 * sc, bot_y + 20 * sc, lx + 12 * sc + stroke, bot_y + 44 * sc, false);
    draw_rectangle(lx + 22 * sc, bot_y + 20 * sc, lx + 22 * sc + stroke, bot_y + 44 * sc, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + letter_h - 6 * sc, true);
    draw_rectangle(lx + letter_w - stroke, bot_y, lx + letter_w, bot_y + letter_h - 6 * sc, true);
    draw_rectangle(lx + 12 * sc, bot_y + 20 * sc, lx + 12 * sc + stroke, bot_y + 44 * sc, true);
    draw_rectangle(lx + 22 * sc, bot_y + 20 * sc, lx + 22 * sc + stroke, bot_y + 44 * sc, true);

    lx += letter_w + gap;

    // A
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, bot_y + 8 * sc + sh, lx + stroke + sh, bot_y + letter_h + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, bot_y + 8 * sc + sh, lx + letter_w + sh, bot_y + letter_h + sh, false);
    draw_rectangle(lx + 6 * sc + sh, bot_y + sh, lx + letter_w - 6 * sc + sh, bot_y + stroke + sh, false);
    draw_rectangle(lx + 6 * sc + sh, bot_y + 22 * sc + sh, lx + letter_w - 6 * sc + sh, bot_y + 22 * sc + stroke + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, bot_y + 8 * sc, lx + stroke, bot_y + letter_h, false);
    draw_rectangle(lx + letter_w - stroke, bot_y + 8 * sc, lx + letter_w, bot_y + letter_h, false);
    draw_rectangle(lx + 6 * sc, bot_y, lx + letter_w - 6 * sc, bot_y + stroke, false);
    draw_rectangle(lx + 6 * sc, bot_y + 22 * sc, lx + letter_w - 6 * sc, bot_y + 22 * sc + stroke, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, bot_y + 8 * sc, lx + stroke, bot_y + letter_h, true);
    draw_rectangle(lx + letter_w - stroke, bot_y + 8 * sc, lx + letter_w, bot_y + letter_h, true);
    draw_rectangle(lx + 6 * sc, bot_y, lx + letter_w - 6 * sc, bot_y + stroke, true);
    draw_rectangle(lx + 6 * sc, bot_y + 22 * sc, lx + letter_w - 6 * sc, bot_y + 22 * sc + stroke, true);

    lx += letter_w + gap;

    // R
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + sh, bot_y + sh, lx + stroke + sh, bot_y + letter_h + sh, false);
    draw_rectangle(lx + stroke + sh, bot_y + sh, lx + letter_w + sh, bot_y + stroke + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, bot_y + sh, lx + letter_w + sh, bot_y + 22 * sc + sh, false);
    draw_rectangle(lx + stroke + sh, bot_y + 22 * sc + sh, lx + letter_w + sh, bot_y + 22 * sc + stroke + sh, false);
    draw_rectangle(lx + 18 * sc + sh, bot_y + 28 * sc + sh, lx + 18 * sc + stroke + sh, bot_y + 44 * sc + sh, false);
    draw_rectangle(lx + 28 * sc + sh, bot_y + 36 * sc + sh, lx + 28 * sc + stroke + sh, bot_y + 52 * sc + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + letter_h, false);
    draw_rectangle(lx + stroke, bot_y, lx + letter_w, bot_y + stroke, false);
    draw_rectangle(lx + letter_w - stroke, bot_y, lx + letter_w, bot_y + 22 * sc, false);
    draw_rectangle(lx + stroke, bot_y + 22 * sc, lx + letter_w, bot_y + 22 * sc + stroke, false);
    draw_rectangle(lx + 18 * sc, bot_y + 28 * sc, lx + 18 * sc + stroke, bot_y + 44 * sc, false);
    draw_rectangle(lx + 28 * sc, bot_y + 36 * sc, lx + 28 * sc + stroke, bot_y + 52 * sc, false);

    draw_set_color(col_outline);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + letter_h, true);
    draw_rectangle(lx + stroke, bot_y, lx + letter_w, bot_y + stroke, true);
    draw_rectangle(lx + letter_w - stroke, bot_y, lx + letter_w, bot_y + 22 * sc, true);
    draw_rectangle(lx + stroke, bot_y + 22 * sc, lx + letter_w, bot_y + 22 * sc + stroke, true);
    draw_rectangle(lx + 18 * sc, bot_y + 28 * sc, lx + 18 * sc + stroke, bot_y + 44 * sc, true);
    draw_rectangle(lx + 28 * sc, bot_y + 36 * sc, lx + 28 * sc + stroke, bot_y + 52 * sc, true);

    draw_set_color(make_color_rgb(18, 22, 30));
    draw_rectangle(lx + 14 * sc, bot_y + 8 * sc, lx + 26 * sc, bot_y + 18 * sc, false);

    lx += letter_w + gap;

    // S
    draw_set_color(col_shadow);
    draw_set_alpha(0.35);
    draw_rectangle(lx + 4 * sc + sh, bot_y + sh, lx + letter_w - 4 * sc + sh, bot_y + stroke + sh, false);
    draw_rectangle(lx + sh, bot_y + sh, lx + stroke + sh, bot_y + 24 * sc + sh, false);
    draw_rectangle(lx + 4 * sc + sh, bot_y + 22 * sc + sh, lx + letter_w - 4 * sc + sh, bot_y + 22 * sc + stroke + sh, false);
    draw_rectangle(lx + letter_w - stroke + sh, bot_y + 22 * sc + sh, lx + letter_w + sh, bot_y + 46 * sc + sh, false);
    draw_rectangle(lx + 4 * sc + sh, bot_y + letter_h - stroke + sh, lx + letter_w - 4 * sc + sh, bot_y + letter_h + sh, false);
    draw_set_alpha(1);

    draw_set_color(col_fill);
    draw_rectangle(lx + 4 * sc, bot_y, lx + letter_w - 4 * sc, bot_y + stroke, false);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + 24 * sc, false);
    draw_rectangle(lx + 4 * sc, bot_y + 22 * sc, lx + letter_w - 4 * sc, bot_y + 22 * sc + stroke, false);
    draw_rectangle(lx + letter_w - stroke, bot_y + 22 * sc, lx + letter_w, bot_y + 46 * sc, false);
    draw_rectangle(lx + 4 * sc, bot_y + letter_h - stroke, lx + letter_w - 4 * sc, bot_y + letter_h, false);

    draw_set_color(col_outline);
    draw_rectangle(lx + 4 * sc, bot_y, lx + letter_w - 4 * sc, bot_y + stroke, true);
    draw_rectangle(lx, bot_y, lx + stroke, bot_y + 24 * sc, true);
    draw_rectangle(lx + 4 * sc, bot_y + 22 * sc, lx + letter_w - 4 * sc, bot_y + 22 * sc + stroke, true);
    draw_rectangle(lx + letter_w - stroke, bot_y + 22 * sc, lx + letter_w, bot_y + 46 * sc, true);
    draw_rectangle(lx + 4 * sc, bot_y + letter_h - stroke, lx + letter_w - 4 * sc, bot_y + letter_h, true);

    draw_set_alpha(1);
    draw_set_color(c_white);
}