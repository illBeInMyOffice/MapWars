function scr_ai_get_strongest_adjacent_enemy(_state_index, _enemy_owner) {
    var s = global.states[_state_index];
    var best_index = -1;
    var best_troops = -9999;
    var i;

    for (i = 0; i < array_length(s.neighbors); i++) {
        var ni = s.neighbors[i];
        var ns = global.states[ni];

        if (ns.owner == _enemy_owner) {
            if (ns.troops > best_troops) {
                best_troops = ns.troops;
                best_index = ni;
            }
        }
    }

    return best_index;
}