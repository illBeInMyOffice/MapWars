{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_ai_get_strongest_adjacent_enemy",
  "tags": [],
  "resourceType": "GMScript",
}