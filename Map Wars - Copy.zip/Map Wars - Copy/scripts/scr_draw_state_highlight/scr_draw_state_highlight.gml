function scr_draw_state_highlight(_state_index, _col, _alpha, _line_w) {
    if (_state_index < 0) return;

    var s = global.states[_state_index];
    var dx = global.MAP_SHIFT_X;
    var dy = global.MAP_SHIFT_Y;

    draw_set_alpha(_alpha);
    draw_set_color(_col);

    var i, j;
    for (i = 0; i < array_length(s.parts); i++) {
        var part = s.parts[i];

        for (j = 0; j < array_length(part); j++) {
            var p1 = part[j];
            var p2 = part[(j + 1) mod array_length(part)];

            draw_line_width(
                p1[0] + dx, p1[1] + dy,
                p2[0] + dx, p2[1] + dy,
                _line_w
            );
        }
    }

    draw_set_alpha(1);
}