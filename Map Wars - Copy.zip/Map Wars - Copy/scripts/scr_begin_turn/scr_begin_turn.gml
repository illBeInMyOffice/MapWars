function scr_begin_turn(_owner) {
    global.current_turn = _owner;
    global.phase = global.PHASE_REINFORCE;
    global.reinforcements_left = scr_calculate_reinforcements(_owner);
    global.selected_state = -1;
    global.move_from_state = -1;
    global.has_moved_this_turn = false;

    if (_owner == global.OWNER_PLAYER) {
        global.message = "Your turn: Reinforcement phase";
        audio_play_sound(snd_turn_start, 1, false);
    } else {
        global.message = "AI turn";
    }
}