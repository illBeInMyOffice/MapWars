function scr_draw_control_panel(_x, _y, _w, _h) {
    scr_draw_console_panel(_x, _y, _w, _h, "");

    var union_states = 0;
    var confed_states = 0;
    var i;

    for (i = 0; i < array_length(global.states); i++) {
        if (global.states[i].owner == global.OWNER_PLAYER) {
            union_states += 1;
        } else {
            confed_states += 1;
        }
    }

    var total_states = max(1, union_states + confed_states);
    var union_frac = union_states / total_states;
    var confed_frac = confed_states / total_states;

    var label_col = make_color_rgb(160, 180, 170);
    var value_col = make_color_rgb(235, 235, 235);

    var blue_col = make_color_rgb(90, 140, 255);
    var red_col = make_color_rgb(220, 95, 95);

    var lx = _x + 14;
    var rx = _x + _w - 14;

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    draw_set_color(label_col);
    draw_text(lx, _y + 30, "UNION");
    draw_text(lx, _y + 68, "CONFED");

    draw_set_halign(fa_right);
    draw_set_color(value_col);
    draw_text(rx, _y + 30, string(union_states));
    draw_text(rx, _y + 68, string(confed_states));

    var bar_x = lx;
    var bar_w = _w - 28;
    var bar_h = 10;

    // union bar
    draw_set_color(make_color_rgb(35, 35, 35));
    draw_rectangle(bar_x, _y + 50, bar_x + bar_w, _y + 50 + bar_h, false);
    draw_set_color(blue_col);
    draw_rectangle(bar_x, _y + 50, bar_x + bar_w * union_frac, _y + 50 + bar_h, false);
    draw_set_color(make_color_rgb(210, 210, 210));
    draw_rectangle(bar_x, _y + 50, bar_x + bar_w, _y + 50 + bar_h, true);

    // confed bar
    draw_set_color(make_color_rgb(35, 35, 35));
    draw_rectangle(bar_x, _y + 88, bar_x + bar_w, _y + 88 + bar_h, false);
    draw_set_color(red_col);
    draw_rectangle(bar_x, _y + 88, bar_x + bar_w * confed_frac, _y + 88 + bar_h, false);
    draw_set_color(make_color_rgb(210, 210, 210));
    draw_rectangle(bar_x, _y + 88, bar_x + bar_w, _y + 88 + bar_h, true);

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}