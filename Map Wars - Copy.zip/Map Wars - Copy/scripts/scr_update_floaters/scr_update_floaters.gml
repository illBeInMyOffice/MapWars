function scr_update_floaters() {
    var new_list = [];
    var i;

    for (i = 0; i < array_length(global.floaters); i++) {
        var f = global.floaters[i];

        f.life -= 1;
        f.y -= 0.4;

        if (f.life > 0) {
            array_push(new_list, f);
        }
    }

    global.floaters = new_list;
}