function scr_draw_state(_index, _is_selected, _is_move_from) {
    var s = global.states[_index];
    var dx = global.MAP_SHIFT_X;
    var dy = global.MAP_SHIFT_Y;

    // ---------------------------------
    // Map intro reveal
    // ---------------------------------
    var reveal_x = 999999;
    if (global.map_intro_active) {
        reveal_x = scr_get_map_intro_reveal_x();
    }

    // ---------------------------------
    // Heatmap color using logarithmic scaling
    // ---------------------------------
    var heat_max = 12;
    var troops_for_heat = max(1, s.troops);

    var heat = ln(troops_for_heat + 1) / ln(heat_max + 1);
    heat = clamp(heat, 0, 1);

    var fill_col;

    if (s.owner == global.OWNER_PLAYER) {
        var pr = round(lerp(30, 110, heat));
        var pg = round(lerp(45, 150, heat));
        var pb = round(lerp(95, 255, heat));
        fill_col = make_color_rgb(pr, pg, pb);
    } else {
        var er = round(lerp(110, 255, heat));
        var eg = round(lerp(35, 105, heat));
        var eb = round(lerp(35, 105, heat));
        fill_col = make_color_rgb(er, eg, eb);
    }

    // ---------------------------------
    // Fill triangles with reveal fade
    // ---------------------------------
    draw_set_color(fill_col);

    var t;
    for (t = 0; t < array_length(s.triangles); t += 6) {
        var vx1 = s.triangles[t + 0] + dx;
        var vy1 = s.triangles[t + 1] + dy;
        var vx2 = s.triangles[t + 2] + dx;
        var vy2 = s.triangles[t + 3] + dy;
        var vx3 = s.triangles[t + 4] + dx;
        var vy3 = s.triangles[t + 5] + dy;

        var tri_min_x = min(vx1, min(vx2, vx3));

        if (!global.map_intro_active || tri_min_x <= reveal_x) {
            var alpha_mul = 1;

            if (global.map_intro_active) {
                var fade_width = 80;
                alpha_mul = clamp((reveal_x - tri_min_x) / fade_width, 0, 1);
            }

            draw_set_alpha(alpha_mul);
            draw_primitive_begin(pr_trianglelist);
            draw_vertex(vx1, vy1);
            draw_vertex(vx2, vy2);
            draw_vertex(vx3, vy3);
            draw_primitive_end();
            draw_set_alpha(1);
        }
    }

    // ---------------------------------
    // White borders with reveal
    // ---------------------------------
    draw_set_color(c_white);

    var i, j;
    for (i = 0; i < array_length(s.parts); i++) {
        var part = s.parts[i];

        for (j = 0; j < array_length(part); j++) {
            var p1 = part[j];
            var p2 = part[(j + 1) mod array_length(part)];

            var x1 = p1[0] + dx;
            var y1 = p1[1] + dy;
            var x2 = p2[0] + dx;
            var y2 = p2[1] + dy;

            if (!global.map_intro_active || min(x1, x2) <= reveal_x) {
                draw_line(x1, y1, x2, y2);
            }
        }
    }

    // ---------------------------------
    // Selection / move highlight
    // ---------------------------------
    if (_is_selected || _is_move_from) {
        if (_is_move_from) {
            draw_set_color(c_lime);
        } else {
            draw_set_color(c_yellow);
        }

        for (i = 0; i < array_length(s.parts); i++) {
            var hpart = s.parts[i];

            for (j = 0; j < array_length(hpart); j++) {
                var a = hpart[j];
                var b = hpart[(j + 1) mod array_length(hpart)];

                var ax = a[0] + dx;
                var ay = a[1] + dy;
                var bx = b[0] + dx;
                var by = b[1] + dy;

                if (!global.map_intro_active || min(ax, bx) <= reveal_x) {
                    draw_line_width(ax, ay, bx, by, 3);
                }
            }
        }
    }

    // ---------------------------------
    // Labels with reveal
    // ---------------------------------
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);

    if (heat > 0.58) {
        draw_set_color(c_black);
    } else {
        draw_set_color(c_white);
    }

    var label_x = s.label_x + dx;
    var abbr_y = s.label_y - 4 + dy;
    var troops_y = s.label_y + 10 + dy;

    if (!global.map_intro_active || label_x <= reveal_x) {
        draw_text(label_x, abbr_y, s.abbr);

        if (!scr_is_small_state_listed(s.abbr)) {
            draw_text(label_x, troops_y, string(s.troops));
        }
    }

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
    draw_set_alpha(1);
}