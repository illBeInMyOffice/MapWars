function scr_check_victory() {
    var player_count = 0;
    var ai_count = 0;
    var i;

    for (i = 0; i < array_length(global.states); i++) {
        if (global.states[i].owner == global.OWNER_PLAYER) {
            player_count += 1;
        } else {
            ai_count += 1;
        }
    }

    if (player_count <= 0) {
        global.game_over = true;
        global.winner = global.OWNER_AI;
        global.message = "The Confederacy wins! Press R to restart.";
        return true;
    }

    if (ai_count <= 0) {
        global.game_over = true;
        global.winner = global.OWNER_PLAYER;
        global.message = "The Union wins! Press R to restart.";
        return true;
    }

    return false;
}