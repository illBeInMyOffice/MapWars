function scr_set_ai_highlight(_a, _b) {
    global.ai_highlight_a = _a;
    global.ai_highlight_b = _b;
    global.ai_highlight_timer = global.AI_HIGHLIGHT_DURATION;
}