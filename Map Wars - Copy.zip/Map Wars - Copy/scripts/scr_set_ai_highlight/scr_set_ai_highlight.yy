{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_set_ai_highlight",
  "tags": [],
  "resourceType": "GMScript",
}