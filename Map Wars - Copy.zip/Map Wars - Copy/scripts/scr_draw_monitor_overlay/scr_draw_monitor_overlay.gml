function scr_draw_monitor_overlay() {
    var x1 = global.monitor_x;
    var y1 = global.monitor_y;
    var w = global.monitor_w;
    var h = global.monitor_h;

    // horizontal scanlines only inside monitor
    draw_set_alpha(0.08);
    draw_set_color(make_color_rgb(180, 255, 210));

    var yy;
    for (yy = y1 + 2; yy < y1 + h - 2; yy += 3) {
        draw_line(x1 + 2, yy, x1 + w - 2, yy);
    }

    draw_set_alpha(1);

    // moving scan bar
    var scan_pos = frac(current_time * 0.00025);
    var bar_y = y1 + 8 + scan_pos * (h - 16);

    draw_set_alpha(0.10);
    draw_set_color(make_color_rgb(255, 220, 120));
    draw_rectangle(x1 + 4, bar_y, x1 + w - 4, bar_y + 8, false);
    draw_set_alpha(1);

    // slight glass reflection in top-left
    draw_set_alpha(0.05);
    draw_set_color(c_white);
    draw_triangle(
        x1 + 12, y1 + 12,
        x1 + 120, y1 + 12,
        x1 + 12, y1 + 70,
        false
    );
    draw_set_alpha(1);
}