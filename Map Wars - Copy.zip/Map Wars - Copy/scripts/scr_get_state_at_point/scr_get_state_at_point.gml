function scr_get_state_at_point(_mx, _my) {
    function point_in_poly(_x, _y, _pts) {
        var inside = false;
        var i;
        var j = array_length(_pts) - 1;

        for (i = 0; i < array_length(_pts); i++) {
            var xi = _pts[i][0];
            var yi = _pts[i][1];
            var xj = _pts[j][0];
            var yj = _pts[j][1];

            var intersect =
                ((yi > _y) != (yj > _y)) &&
                (_x < (xj - xi) * (_y - yi) / ((yj - yi) + 0.00001) + xi);

            if (intersect) inside = !inside;
            j = i;
        }

        return inside;
    }

    var local_x = _mx - global.MAP_SHIFT_X;
    var local_y = _my - global.MAP_SHIFT_Y;

    var i;
    var p;
    for (i = array_length(global.states) - 1; i >= 0; i--) {
        var s = global.states[i];

        if (local_x >= s.x && local_x <= s.x + s.w && local_y >= s.y && local_y <= s.y + s.h) {
            var hit = false;

            var part_index;
            for (part_index = 0; part_index < array_length(s.parts); part_index++) {
                if (point_in_poly(local_x, local_y, s.parts[part_index])) {
                    hit = true;
                    break;
                }
            }

            if (hit) {
                return i;
            }
        }
    }

    return -1;
}