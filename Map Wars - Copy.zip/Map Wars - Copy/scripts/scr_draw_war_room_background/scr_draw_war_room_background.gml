function scr_draw_war_room_background() {
    var gw = global.gui_w;
    var gh = global.gui_h;

    // -----------------------------
    // Layout
    // -----------------------------
    var outer_x = 40;
    var outer_y = 30;
    var outer_w = gw - 80;
    var outer_h = gh - 60;

    var mon_x = 220;
    var mon_y = 120;
    var mon_w = gw - 320;
    var mon_h = gh - 210;

    global.monitor_x = mon_x;
    global.monitor_y = mon_y;
    global.monitor_w = mon_w;
    global.monitor_h = mon_h;

    // -----------------------------
    // Base room background
    // -----------------------------
    draw_set_color(make_color_rgb(10, 14, 12));
    draw_rectangle(0, 0, gw, gh, false);

    draw_set_alpha(0.12);
    draw_set_color(make_color_rgb(30, 45, 34));
    draw_rectangle(0, 0, gw, gh, false);
    draw_set_alpha(1);

    // -----------------------------
    // Outer console shadow
    // -----------------------------
    draw_set_alpha(0.35);
    draw_set_color(c_black);
    draw_rectangle(outer_x + 8, outer_y + 8, outer_x + outer_w + 8, outer_y + outer_h + 8, false);
    draw_set_alpha(1);

    // -----------------------------
    // Outer console body
    // -----------------------------
    draw_set_color(make_color_rgb(36, 40, 38));
    draw_rectangle(outer_x, outer_y, outer_x + outer_w, outer_y + outer_h, false);

    // Bevel
    draw_set_color(make_color_rgb(90, 96, 90));
    draw_line_width(outer_x, outer_y, outer_x + outer_w, outer_y, 2);
    draw_line_width(outer_x, outer_y, outer_x, outer_y + outer_h, 2);

    draw_set_color(make_color_rgb(18, 20, 18));
    draw_line_width(outer_x, outer_y + outer_h, outer_x + outer_w, outer_y + outer_h, 2);
    draw_line_width(outer_x + outer_w, outer_y, outer_x + outer_w, outer_y + outer_h, 2);

    draw_set_color(make_color_rgb(210, 210, 210));
    draw_rectangle(outer_x, outer_y, outer_x + outer_w, outer_y + outer_h, true);

    // -----------------------------
    // Inner monitor recess shadow
    // -----------------------------
    draw_set_alpha(0.4);
    draw_set_color(c_black);
    draw_rectangle(mon_x + 5, mon_y + 5, mon_x + mon_w + 5, mon_y + mon_h + 5, false);
    draw_set_alpha(1);

    // -----------------------------
    // Monitor recess
    // -----------------------------
    draw_set_color(make_color_rgb(22, 24, 24));
    draw_rectangle(mon_x, mon_y, mon_x + mon_w, mon_y + mon_h, false);

    // Recess bevel
    draw_set_color(make_color_rgb(12, 12, 12));
    draw_line_width(mon_x, mon_y, mon_x + mon_w, mon_y, 2);
    draw_line_width(mon_x, mon_y, mon_x, mon_y + mon_h, 2);

    draw_set_color(make_color_rgb(105, 110, 105));
    draw_line_width(mon_x, mon_y + mon_h, mon_x + mon_w, mon_y + mon_h, 2);
    draw_line_width(mon_x + mon_w, mon_y, mon_x + mon_w, mon_y + mon_h, 2);

    draw_set_color(make_color_rgb(220, 220, 220));
    draw_rectangle(mon_x, mon_y, mon_x + mon_w, mon_y + mon_h, true);

    // -----------------------------
    // Monitor glass / tint
    // -----------------------------
    draw_set_alpha(0.20);
    draw_set_color(make_color_rgb(40, 70, 58));
    draw_rectangle(mon_x + 2, mon_y + 2, mon_x + mon_w - 2, mon_y + mon_h - 2, false);
    draw_set_alpha(1);

    // Subtle inner glow
    draw_set_alpha(0.08);
    draw_set_color(make_color_rgb(120, 180, 150));
    draw_rectangle(mon_x + 6, mon_y + 6, mon_x + mon_w - 6, mon_y + mon_h - 6, true);
    draw_set_alpha(1);

    // -----------------------------
    // Top label strip
    // -----------------------------
    var strip_x = mon_x;
    var strip_y = mon_y - 26;
    var strip_w = mon_w;
    var strip_h = 10;

    draw_set_color(make_color_rgb(70, 66, 38));
    draw_rectangle(strip_x, strip_y, strip_x + strip_w, strip_y + strip_h, false);

    draw_set_color(make_color_rgb(255, 210, 80));
    draw_line_width(strip_x + 10, strip_y + strip_h * 0.5, strip_x + strip_w - 10, strip_y + strip_h * 0.5, 2);

    draw_circle(strip_x + strip_w * 0.5, strip_y + strip_h * 0.5, 3, false);

    // -----------------------------
    // Console corner accents
    // -----------------------------
    var c = make_color_rgb(255, 210, 80);

    draw_set_color(c);
    // top-left
    draw_line_width(outer_x + 14, outer_y + 14, outer_x + 40, outer_y + 14, 2);
    draw_line_width(outer_x + 14, outer_y + 14, outer_x + 14, outer_y + 40, 2);

    // top-right
    draw_line_width(outer_x + outer_w - 14, outer_y + 14, outer_x + outer_w - 40, outer_y + 14, 2);
    draw_line_width(outer_x + outer_w - 14, outer_y + 14, outer_x + outer_w - 14, outer_y + 40, 2);

    // bottom-left
    draw_line_width(outer_x + 14, outer_y + outer_h - 14, outer_x + 40, outer_y + outer_h - 14, 2);
    draw_line_width(outer_x + 14, outer_y + outer_h - 14, outer_x + 14, outer_y + outer_h - 40, 2);

    // bottom-right
    draw_line_width(outer_x + outer_w - 14, outer_y + outer_h - 14, outer_x + outer_w - 40, outer_y + outer_h - 14, 2);
    draw_line_width(outer_x + outer_w - 14, outer_y + outer_h - 14, outer_x + outer_w - 14, outer_y + outer_h - 40, 2);

    // -----------------------------
    // Decorative console bolts / knobs
    // -----------------------------
    draw_set_color(make_color_rgb(20, 20, 20));
    draw_circle(mon_x + 30, mon_y + mon_h - 20, 8, false);
    draw_circle(mon_x + 52, mon_y + mon_h - 20, 8, false);

    draw_set_color(make_color_rgb(220, 220, 220));
    draw_circle(mon_x + 30, mon_y + mon_h - 20, 8, true);
    draw_circle(mon_x + 52, mon_y + mon_h - 20, 8, true);

    // Right speaker / vent
    var vent_r = 24;
    var vent_x = mon_x + mon_w - 38;
    var vent_y = mon_y + mon_h - 36;

    draw_set_color(make_color_rgb(18, 18, 18));
    draw_circle(vent_x, vent_y, vent_r, false);
    draw_set_color(make_color_rgb(220, 220, 220));
    draw_circle(vent_x, vent_y, vent_r, true);

    var vx;
    for (vx = -16; vx <= 16; vx += 5) {
        draw_line(vent_x + vx, vent_y - 16, vent_x + vx, vent_y + 16);
    }
}