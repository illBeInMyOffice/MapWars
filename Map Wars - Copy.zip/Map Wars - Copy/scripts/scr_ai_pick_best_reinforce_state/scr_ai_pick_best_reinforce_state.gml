function scr_ai_pick_best_reinforce_state() {
    var best_index = -1;
    var best_score = -999999;
    var i;

    for (i = 0; i < array_length(global.states); i++) {
        if (global.states[i].owner == global.OWNER_AI) {
            var _score = scr_ai_score_reinforce_state(i);

            if (_score > best_score) {
                best_score = _score;
                best_index = i;
            }
        }
    }

    return best_index;
}