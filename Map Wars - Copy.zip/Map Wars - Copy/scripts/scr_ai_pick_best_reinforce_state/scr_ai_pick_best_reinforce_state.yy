{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_ai_pick_best_reinforce_state",
  "tags": [],
  "resourceType": "GMScript",
}