function scr_ai_score_attack(_from_index, _to_index) {
    var p = global.ai_profile;
    var from_s = global.states[_from_index];
    var to_s = global.states[_to_index];

    if (from_s.owner != global.OWNER_AI) return -999999;
    if (to_s.owner != global.OWNER_PLAYER) return -999999;
    if (from_s.troops < 2) return -999999;

    var available_attack_power = from_s.troops - 1;
    var diff = available_attack_power - to_s.troops;

    if (diff < -1) {
        if (random(1) > p.attack_risky_chance) {
            return -999999;
        }
    } else if (diff == -1 || diff == 0) {
        if (random(1) > p.attack_equal_chance) {
            return -999999;
        }
    } else {
        if (diff < p.attack_min_advantage) {
            return -999999;
        }
    }

    var _score = 0;

    _score += diff * 10;
    _score += max(0, 6 - to_s.troops) * 2;

    // Prefer attacking states that themselves touch more player territory
    // because captures there can open up fronts.
    var enemy_neighbors_of_target = scr_ai_count_enemy_neighbors(_to_index, global.OWNER_AI);
    _score += enemy_neighbors_of_target * 2;

    _score += random(2);

    return _score;
}