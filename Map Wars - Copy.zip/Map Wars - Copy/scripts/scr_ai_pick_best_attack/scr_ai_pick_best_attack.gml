function scr_ai_pick_best_attack() {
    var best = {
        from_index: -1,
        to_index: -1,
        _score: -999999
    };

    var i, n;

    for (i = 0; i < array_length(global.states); i++) {
        var s = global.states[i];

        if (s.owner != global.OWNER_AI) continue;
        if (s.troops < 2) continue;

        for (n = 0; n < array_length(s.neighbors); n++) {
            var ni = s.neighbors[n];

            if (global.states[ni].owner == global.OWNER_PLAYER) {
                var _score = scr_ai_score_attack(i, ni);

                if (_score > best._score) {
                    best.from_index = i;
                    best.to_index = ni;
                    best._score = _score;
                }
            }
        }
    }

    return best;
}