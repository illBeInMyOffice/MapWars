function scr_draw_message_bar(_x, _y, _w, _h) {
    // compact message strip, no title bar
    draw_set_alpha(0.18);
    draw_set_color(c_black);
    draw_rectangle(_x + 3, _y + 3, _x + _w + 3, _y + _h + 3, false);
    draw_set_alpha(1);

    draw_set_color(make_color_rgb(20, 24, 24));
    draw_rectangle(_x, _y, _x + _w, _y + _h, false);

    draw_set_color(make_color_rgb(210, 210, 210));
    draw_rectangle(_x, _y, _x + _w, _y + _h, true);

    draw_set_color(make_color_rgb(255, 210, 80));
    draw_line_width(_x + 10, _y + 8, _x + _w - 10, _y + 8, 2);

    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(make_color_rgb(235, 235, 235));
    draw_text(_x + _w * 0.5, _y + _h * 0.5 + 2, global.message);

    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
}