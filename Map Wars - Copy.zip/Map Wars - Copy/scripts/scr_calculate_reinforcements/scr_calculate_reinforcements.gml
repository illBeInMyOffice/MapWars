function scr_calculate_reinforcements(_owner) {
    var territories = 0;
    var i;

    for (i = 0; i < array_length(global.states); i++) {
        if (global.states[i].owner == _owner) {
            territories += 1;
        }
    }

    return max(3, floor(territories / 3));
}