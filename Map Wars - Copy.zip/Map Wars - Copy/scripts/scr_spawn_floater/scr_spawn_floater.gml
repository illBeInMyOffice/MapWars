function scr_spawn_floater(_state_index, _text, _col) {
    if (_state_index < 0) return;

    var s = global.states[_state_index];

    var fx = s.label_x + global.MAP_SHIFT_X;
    var fy = s.label_y + global.MAP_SHIFT_Y;

    array_push(global.floaters, {
        x: fx,
        y: fy,
        text: _text,
        col: _col,
        life: global.FLOATER_LIFE,
        max_life: global.FLOATER_LIFE
    });
}