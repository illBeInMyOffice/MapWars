function scr_draw_title_state_floater(_floater) {
    var s = global.states[_floater.state_index];

    var cx = s.label_x;
    var cy = s.label_y;

    var i, j;

    // Filled triangles
    draw_set_alpha(_floater.alpha);
    draw_set_color(_floater.col);

    draw_primitive_begin(pr_trianglelist);

    for (i = 0; i < array_length(s.triangles); i += 6) {
        var x1 = s.triangles[i + 0] - cx;
        var y1 = s.triangles[i + 1] - cy;
        var x2 = s.triangles[i + 2] - cx;
        var y2 = s.triangles[i + 3] - cy;
        var x3 = s.triangles[i + 4] - cx;
        var y3 = s.triangles[i + 5] - cy;

        var d1 = point_distance(0, 0, x1, y1) * _floater.scale;
        var d2 = point_distance(0, 0, x2, y2) * _floater.scale;
        var d3 = point_distance(0, 0, x3, y3) * _floater.scale;

        var a1 = point_direction(0, 0, x1, y1) + _floater.rot;
        var a2 = point_direction(0, 0, x2, y2) + _floater.rot;
        var a3 = point_direction(0, 0, x3, y3) + _floater.rot;

        draw_vertex(_floater.x + lengthdir_x(d1, a1), _floater.y + lengthdir_y(d1, a1));
        draw_vertex(_floater.x + lengthdir_x(d2, a2), _floater.y + lengthdir_y(d2, a2));
        draw_vertex(_floater.x + lengthdir_x(d3, a3), _floater.y + lengthdir_y(d3, a3));
    }

    draw_primitive_end();

    // Borders from original polygon parts
    draw_set_color(make_color_rgb(220, 220, 220));
    draw_set_alpha(_floater.alpha * 0.75);

    for (i = 0; i < array_length(s.parts); i++) {
        var part = s.parts[i];

        for (j = 0; j < array_length(part); j++) {
            var p1 = part[j];
            var p2 = part[(j + 1) mod array_length(part)];

            var x1b = p1[0] - cx;
            var y1b = p1[1] - cy;
            var x2b = p2[0] - cx;
            var y2b = p2[1] - cy;

            var d1b = point_distance(0, 0, x1b, y1b) * _floater.scale;
            var d2b = point_distance(0, 0, x2b, y2b) * _floater.scale;

            var a1b = point_direction(0, 0, x1b, y1b) + _floater.rot;
            var a2b = point_direction(0, 0, x2b, y2b) + _floater.rot;

            draw_line(
                _floater.x + lengthdir_x(d1b, a1b),
                _floater.y + lengthdir_y(d1b, a1b),
                _floater.x + lengthdir_x(d2b, a2b),
                _floater.y + lengthdir_y(d2b, a2b)
            );
        }
    }

    draw_set_alpha(1);
    draw_set_color(c_white);
}