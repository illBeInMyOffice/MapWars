{
  "isDnD": false,
  "isCompatibility": false,
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy",
  },
  "resourceVersion": "1.0",
  "name": "scr_ai_state_is_frontline",
  "tags": [],
  "resourceType": "GMScript",
}