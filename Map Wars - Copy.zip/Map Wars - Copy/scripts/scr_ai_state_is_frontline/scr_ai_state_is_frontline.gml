function scr_ai_state_is_frontline(_state_index, _owner_to_check_against) {
    var s = global.states[_state_index];
    var i;

    for (i = 0; i < array_length(s.neighbors); i++) {
        var ni = s.neighbors[i];
        if (global.states[ni].owner == _owner_to_check_against) {
            return true;
        }
    }

    return false;
}