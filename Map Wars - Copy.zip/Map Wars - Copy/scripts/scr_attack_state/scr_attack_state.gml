function scr_attack_state(_attacker_index, _defender_index) {
    var a = global.states[_attacker_index];
    var d = global.states[_defender_index];

    if (a.owner == d.owner) return false;
    if (a.troops < 2) return false;

    var attacker_owner = a.owner;

    var attack_roll = irandom_range(1, 6);
    var defend_roll = irandom_range(1, 6);

    attack_roll += min(3, a.troops - 1);
    defend_roll += min(2, d.troops);

    if (attack_roll > defend_roll) {
        d.troops -= 1;
        scr_spawn_floater(_defender_index, "-1", c_yellow);

        global.message = a.abbr + " attacks " + d.abbr + ": WIN (" + string(attack_roll) + " vs " + string(defend_roll) + ")";

        if (attacker_owner == global.OWNER_PLAYER) {
            audio_play_sound(snd_battle_win, 1, false);
        } else {
            audio_play_sound(snd_battle_lose, 1, false);
        }

        if (d.troops <= 0) {
            d.owner = a.owner;
            d.troops = 1;
            a.troops -= 1;

            scr_spawn_floater(_attacker_index, "-1", c_yellow);
            scr_spawn_floater(_defender_index, "CAPTURED!", c_aqua);

            global.message = a.abbr + " captured " + d.abbr + "!";

            if (attacker_owner == global.OWNER_PLAYER) {
                audio_play_sound(snd_victory_cheer, 1, false);
            }
        }
    } else {
        a.troops -= 1;
        scr_spawn_floater(_attacker_index, "-1", c_yellow);

        global.message = a.abbr + " attacks " + d.abbr + ": LOSE (" + string(attack_roll) + " vs " + string(defend_roll) + ")";

        if (attacker_owner == global.OWNER_PLAYER) {
            audio_play_sound(snd_battle_lose, 1, false);
        } else {
            audio_play_sound(snd_battle_win, 1, false);
        }
    }

    global.states[_attacker_index] = a;
    global.states[_defender_index] = d;

    return true;
}