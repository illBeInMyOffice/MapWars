function scr_ai_score_move(_from_index, _to_index) {
    var p = global.ai_profile;
    var from_s = global.states[_from_index];
    var to_s = global.states[_to_index];

    if (from_s.owner != global.OWNER_AI) return -999999;
    if (to_s.owner != global.OWNER_AI) return -999999;
    if (from_s.troops < 2) return -999999;

    var _score = 0;

    var to_is_frontline = scr_ai_state_is_frontline(_to_index, global.OWNER_PLAYER);
    var from_is_frontline = scr_ai_state_is_frontline(_from_index, global.OWNER_PLAYER);

    if (!from_is_frontline && to_is_frontline) {
        _score += 14 * p.move_frontline_bias;
    }

    var to_enemy_neighbors = scr_ai_count_enemy_neighbors(_to_index, global.OWNER_PLAYER);
    _score += to_enemy_neighbors * 4 * p.move_support_bias;

    var strongest_enemy = scr_ai_get_strongest_adjacent_enemy(_to_index, global.OWNER_PLAYER);
    if (strongest_enemy != -1) {
        var deficit = max(0, global.states[strongest_enemy].troops - to_s.troops);
        _score += deficit * 4 * p.move_support_bias;
    }

    // discourage stripping already weak frontline states
    if (from_is_frontline && from_s.troops <= 3) {
        _score -= 12;
    }

    _score += random(p.move_randomness * 10);

    return _score;
}